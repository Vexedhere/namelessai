# Nameless Labs AI — V5.1 "Arc"

## What's new in V5.1: the voice HUD

Tap the mic and the app switches to a full-screen, JARVIS-style voice screen (`components/VoiceHUD.tsx`):

- **Name your AI at the centre.** If your AI has no name yet, the ring says *NAME YOUR AI*. Type a name, tap an idea, or just say it out loud ("call you Nova"). Once named, the name sits in the core in dotted style (N.O.V.A.).
- **It talks first.** On open it greets you out loud with its name and version (`lib/hud.ts`), then starts listening.
- **Live state.** Rings, band and waveform react to standing by / listening / thinking / speaking; live captions show what you said and what the AI is saying.
- **Modes:** Tap (listen once), Wake word ("Hey <name>") and Open mic. Keys `1 2 3`.
- **Controls:** language, voice picker, speaking speed, volume, mute (captions only), type-instead box, quick-command chips, full screen, 6 HUD colours (incl. match-theme).
- **Telemetry:** clock, link status, battery, session timer, turn count, active model and Actions state.
- **Keys:** `Space` skip/wake · `M` mute · `T` type · `S` settings · `F` full screen · `Esc` close.
- **Version V5.1** is defined once in `lib/version.ts` and shown in the header, sidebar and HUD. The AI is told its version too, so "which version are you?" works.

# Nameless Labs AI

Premium dark-glass chat workspace (390 switchable colour themes) (Next.js 14 · Tailwind · OpenRouter) with six model tiers,
live streaming replies, Markdown + code rendering, chat history and a mobile-friendly layout.

## Deploy on Vercel

1. Push this folder to GitHub and import it in Vercel (framework: Next.js is auto-detected).
2. **Project → Settings → Environment Variables** → add `OPENROUTER_API_KEY` (all environments).
3. Redeploy. Done.

## Supabase login (Google · GitHub · Email) — project `nzaelikbjumaidaombmp`

1. **Env vars** (Vercel + `.env.local`): `NEXT_PUBLIC_SUPABASE_ANON_KEY` = the anon/publishable key from
   Supabase → Project Settings → API. (`NEXT_PUBLIC_SUPABASE_URL` already defaults to your project.)
2. **Auth → URL Configuration**: set *Site URL* to your Vercel URL and add it (plus `http://localhost:3000`)
   to *Redirect URLs*.
3. **Auth → Providers**: enable Google and GitHub (paste each provider's client ID/secret; use the
   callback URL `https://nzaelikbjumaidaombmp.supabase.co/auth/v1/callback` in the Google/GitHub consoles) and Email.
4. **SQL Editor**: run `supabase/schema.sql` once. It creates the `chats` table with Row Level Security so
   each user can only read/write their own chats.

Guests see "Guest" in the sidebar and keep chats on-device. After login the sidebar shows the user's name and
profile picture, chats sync to the cloud, and any guest chats are carried over.

## Team / company knowledge

`lib/team.ts` holds the leadership list (Chethan – Main Founder · Vijay – CEO · Kedar – CMO / MD). It is injected into every
model's system prompt, so "who is the CEO / founder / CMO?" is answered correctly on all tiers. Add people by adding a line to `TEAM`.

## More agent tools

| Say | Tool |
|---|---|
| "Add send invoice to my tasks" · "what's on my to-do list" · "mark invoice done" | `manage_tasks` (this browser) |
| "2500 USD in INR" | `convert_currency` (ECB rates via Frankfurter) |
| "5 km in miles" · "98.6 F to C" | `convert_units` |
| "Time in Tokyo" | `world_time` |
| "Who is Alan Turing" | `wikipedia_summary` |
| "Define ephemeral" | `define_word` |
| "Read https://… and summarise" | `read_webpage` (public pages only; private/internal addresses blocked) |
| "Search the web for …" | `web_search` (needs `TAVILY_API_KEY`) |
| "Strong 20 char password" · "roll two dice" · "pick pizza or burgers" | `generate_password`, `random_pick` |
| "Switch to the Ember theme" · "copy that" | `set_theme`, `copy_to_clipboard` |

| "EMI for 20 lakh at 9% for 15 years" · "SIP of 5000 for 10 years" · "18% GST on 4500" | `finance_calc` |
| "Days until 2027-01-26" · "what weekday is 2026-12-25" | `date_calc` |
| "Spent 450 on lunch" · "how much did I spend this month" | `manage_expenses` |
| "Log gym" · "what's my reading streak" | `track_habit` |
| "Bookmark this link under reading" | `manage_bookmarks` |
| "25 minute focus session on the pitch deck" | `start_focus_session` |
| "Word count / base64 / SHA-256 of …" | `text_tools` |
| "#8b5cf6 as rgb" | `color_convert` |
| "News about AI" · "bitcoin price" · "facts about Japan" · "holidays in India" | `get_news`, `get_crypto_price`, `country_info`, `public_holidays` |

## Modes

Pick a working mode from the header (Senior Engineer, Writer, Tutor, Analyst, Marketing Lead, Startup Coach, Brief). Edit or add modes in `lib/personas.ts`.

## Themes

Aurora (default), Ember, Emerald, Ocean, Rose — pick from the colour dot in the header, or ask the AI. The palette is a set of CSS variables
in `app/globals.css`; Tailwind's `cyan-*` scale points at them (see `tailwind.config.js`), so add a theme by adding one `html[data-theme=…]`
block there plus an entry in `lib/theme.ts`.

## Run locally

```bash
npm install
cp .env.example .env.local   # then paste your OpenRouter key
npm run dev                  # http://localhost:3000
```

## Model tiers

| Tier | OpenRouter slug (default) |
|---|---|
| NamelessAI (Custom Fine-Tuned) | `qwen/qwen-2.5-72b-instruct` (or your `CUSTOM_MODEL_URL`) |
| Pulse 5.5 Nano | `meta-llama/llama-3.2-3b-instruct` |
| Lyric 5.5 Flash | `google/gemini-2.5-flash` |
| Vega 5.5 Mini | `openai/gpt-4o-mini` |
| Aether 5.5 Pro | `anthropic/claude-sonnet-5.5` |
| Quasar 5.5 Apex | `deepseek/deepseek-r1-0528` |

OpenRouter retires and renames models. If a tier ever errors with "model not found", set e.g.
`MODEL_AETHER_PRO=<new-slug>` in Vercel – no code change needed (see `.env.example`).

## Agent actions + voice

NamelessAI can *do* things, not just chat. Ask in text or by voice (mic button, bottom right):

| Say | What happens |
|---|---|
| "Wake me at 6:30" · "remind me at 5pm to call mom" · "every weekday at 7" | alarm on your device (rings + notification + spoken) |
| "Timer for 10 minutes" | countdown timer |
| "Email Rahul about tomorrow's meeting being moved to 3" | AI writes the email → **you review/edit → Send** |
| "Save Rahul's email as rahul@x.com" | contact book (this browser) |
| "Note: renew domain" · "what's on my shopping list?" | notes/lists (this browser) |
| "Weather in Pune" · "what's 18% of 2450" · "open github.com" | weather (Open-Meteo), exact maths, open a tab |

**Voice mode** is hands-free: it listens, sends when you stop talking, speaks the answer sentence-by-sentence
while it streams, then listens again. Tap the orb to skip speech, ✕ or Esc to leave. Uses the browser's built-in
speech recognition + synthesis (Chrome, Edge, Safari; no key needed; language picker included).
For emails in voice mode it reads the draft back and waits for "send" / "cancel".

How it works: `/api/chat` forwards tool schemas to the model (OpenAI-style function calling via OpenRouter) and
streams NDJSON events (`text`, `tool_calls`). `app/page.tsx` runs the loop: execute tools → send results back →
repeat (max 6 steps). Alarms/notes/contacts/maths run in the browser (`lib/clientTools.ts`); weather and email
run on the server (`app/api/tools/route.ts`).

**Safety:** emails are never sent without an explicit confirmation click/voice "send"; only signed-in users can send;
sender identity is transparent ("sent on behalf of …", Reply-To = the user); rate-limited; no tool can read your
files or inbox.

**Limits to know**
- Alarms live in the browser: they ring while the page is open in a tab (background tab OK, closed tab/phone asleep not).
  True background alarms would need a service worker + Web Push (not included).
- Models that can't call tools (Pulse Nano, Quasar Apex — see `tools:` in `lib/models.ts`) run as plain chat; the
  "Actions" toggle in the header is disabled for them. Flip the flag if your slug supports tools.
- With actions on, the NamelessAI tier goes through OpenRouter (your `CUSTOM_MODEL_URL` endpoint is used when actions are off).
- Set `RESEND_API_KEY` + `EMAIL_FROM` to send directly; otherwise the card opens your mail app with the draft.

### Add your own tool
1. Add a schema to `TOOL_DEFS` (+ a label in `TOOL_LABELS`) in `lib/toolDefs.ts`.
2. Browser-side: add a `case` in `lib/clientTools.ts`. Server-side: add the name to `SERVER_TOOLS` and a handler in `app/api/tools/route.ts`.

## Structure

- `lib/models.ts` – tier names, badges, taglines (edit to rebrand)
- `app/api/chat/route.ts` – validated, streaming OpenRouter proxy with tool calling (key stays server-side)
- `app/api/tools/route.ts` – server tools (email via Resend, weather) · `lib/clientTools.ts` – browser tools
- `lib/voice.ts`, `lib/useVoiceMode.ts` – speech in/out · `lib/alarms.ts`, `components/AlarmRinger.tsx` – alarms
- `components/` – UI building blocks · `app/page.tsx` – chat state & streaming client
- `colab_train_namelessai.py` – fine-tuning script for the custom tier


## v5: accounts, AI naming, 390 themes

**Run `supabase/schema.sql` again** (it now also creates `user_settings`). Without it, sign-in works but settings/data won't save.

- **Name your AI** – a popup on first visit. The name is sent with every message, so the AI introduces itself and answers to it. Click *Rename* on the home screen to change it.
- **Saved to the account, not the device** – signed-in users get chats, AI name, theme, persona, model, voice language, Actions toggle and the AI's tasks / notes / contacts / alarms / expenses / bookmarks / habits stored in Supabase (RLS: each user only sees their own rows). Nothing is written to `localStorage`.
- **Guests are not saved** – a banner and the sidebar say so. Everything lives in memory and is gone on refresh. (The AI name and theme are kept only for the current tab via `sessionStorage`.) Chats made in a tab before signing in are kept and saved to the account on sign-in.
- **Google login** – enable the Google provider in Supabase → Authentication → Providers and add your site URL under URL Configuration.
- **390 themes** – 26 colours × 15 styles (e.g. *Ruby Midnight*, *Azure Neon*), searchable in the header picker. The AI can switch them too: "set the theme to violet noir", "random theme".


## v6: always-listening + device control

### Always listening (hands-free)
Click the **headset button** next to the mic. After that you never touch the app again:

| You say | What happens |
|---|---|
| "Hey Nova, what's the weather?" (Nova = your AI's name; "Nameless" always works too) | wakes up, answers out loud |
| *(keep talking, no wake word needed for 30 s)* | the conversation stays open after each answer |
| "Stop listening" / "go to sleep" / "goodbye" | back to standby, waiting for its name |
| "Open mic" / "respond to everything" | answers everything it hears, no wake word |
| "Wait for my name" | back to wake-word mode |
| "Turn off voice" | switches hands-free off |

The chip in the voice bar flips between **Wake word** and **Open mic**. A short chime confirms it heard you. It keeps the screen awake while on
(a sleeping phone screen silences the browser microphone). Speech recognition is the browser's built-in one (Chrome / Edge / Safari). In Chrome that
audio is processed by Google's speech service, same as the original voice mode.

Limits: it can't hear you while it is talking (so it never answers itself); tap the orb to skip. The microphone only works while the tab is open,
and phones may beep each time the browser reopens the mic. Everything it hears in wake-word mode is discarded unless it starts with the wake word.

### Device control, two layers
A web page cannot change your volume or lock your screen, so there are two layers:

**1. Works instantly, no install** (browser powers): battery · network · screen · location · fullscreen · keep-screen-on · print · flashlight and vibration (Android Chrome) ·
system notifications · speak aloud · read clipboard · save files to Downloads · open dialer / SMS / WhatsApp / Maps directions / YouTube / Spotify (they open prefilled; you press call/send) ·
and the AI can operate the app itself (new chat, switch model/mode, voice language/speed/volume, always-listening on/off).

**2. Real computer control** via the optional companion, `public/nameless_agent.py` (served at `/nameless_agent.py`; Python 3, no installs):

```bash
python3 nameless_agent.py --origin https://YOUR-SITE.vercel.app            # volume, brightness, media keys, apps, screenshots…
python3 nameless_agent.py --origin https://YOUR-SITE.vercel.app --allow-power --allow-input   # + lock/sleep/shutdown/restart, typing/keys
```
Then click the laptop icon in the header (**Devices**), paste the pairing code it prints, and say things like *"set volume to 30"*, *"open Spotify"*,
*"pause the music"*, *"take a screenshot"*, *"lock my screen"*.

Security model: listens on 127.0.0.1 only · every request needs the secret code **and** an allowed `--origin` · fixed action list, no shell, user text only ever passed as data ·
power/typing actions are off unless you start it with the flag **and** the app asks you to approve shutdown/restart/sleep/typing/key presses every time (click Allow or say "yes") ·
rate-limited · everything is logged in its terminal · Ctrl+C revokes access instantly. The pairing code is stored in this browser's localStorage only (the one exception to "nothing in localStorage", because it's a per-device secret) and never uploaded.
Works in Chrome, Edge and Firefox; Safari blocks web pages from reaching localhost. Recent Chrome may ask you to allow "local network access" once.

**Honest status:** the companion's server/security layer is tested (wrong code, wrong site, DNS-rebinding Host, flags, rate limit, injection attempts).
The OS commands (volume/brightness/media/screenshot/lock…) are written for Windows, macOS and Linux but depend on your machine
(Linux needs `wpctl`, `pactl` or `amixer`; brightness needs `brightnessctl`; macOS brightness needs `brew install brightness`; typing on Linux needs `xdotool` and X11). They haven't been run on real hardware here, so expect to report/fix a quirk or two.

### Add your own device action
Browser-side: add a tool in `lib/toolDefs.ts` and a case in `lib/deviceTools.ts`. Computer-side: add a function and an entry to `ACTIONS` in `public/nameless_agent.py`
(put it in `POWER` or `INPUT` if it's risky) and the action name to the enum of `computer_control`.

### New files
`lib/wake.ts` wake-word + spoken-command matching · `lib/useVoiceMode.ts` (rewritten: push / wake / open modes) · `lib/deviceTools.ts` · `lib/companion.ts` · `lib/appBus.ts` ·
`components/DevicesPanel.tsx`, `components/ActionConfirm.tsx` · `public/nameless_agent.py`
